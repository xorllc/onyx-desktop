# bjne forked

元リポジトリは現在の環境ではビルドが通らなかったりしたので適当に修正。

## Required Packages

* g++
* boost
* SDL
* [SCons](http://scons.org/)

## Build

    $ scons

## Running bjne

    $ bjne <rom-filename>

## License

New BSD License (see LICENSE file).
