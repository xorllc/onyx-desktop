#pragma once

#include "../nes.h"

class null_mapper : public mapper {
};
